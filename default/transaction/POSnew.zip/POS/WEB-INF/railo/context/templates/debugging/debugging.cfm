<cfadmin action="printDebug">

